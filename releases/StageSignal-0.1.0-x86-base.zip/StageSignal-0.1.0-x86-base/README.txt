StageSignal 0.1.0 (x86-base) - Visual Core Beta, unsigned
========================================================
Run StageSignal.exe. No installer, no network, no login. Nothing is downloaded or installed.
Settings, autosaves, logs and benchmark results are stored in %LOCALAPPDATA%\StageSignal (not in this folder).
Delete this folder to uninstall; your shows and recordings are kept.

Start here
  1. Setup tab: identify displays, choose audio input, set hardware gain, run the benchmark.
  2. File > Open show... and choose samples\demo.stagesignal (12 scenes, 8 programmed cues, 4 text messages).
  3. Live tab: keys 1-8 pick scenes, F5 next, F6 pause, F7 resume, F8 emergency blackout, Shift+F8 restore, F1 help.
  DMX, recording and broadcasting are always OFF at startup and need an explicit Start/Arm.

Command line
  StageSignal.exe --version | --selftest | --benchmark [--out file.json] [--scale 0.1] | --data-dir <folder>

Contents: StageSignal.exe, assets\ (original CC0 procedural assets + manifest), licenses\ (inventory + third-party notices),
          docs\help\ (offline help sources, also embedded in the exe), samples\ (demo show), docs\LIGHTING.md.
Build: x86-base build, MinGW-w64 static, Windows Vista-or-later API set resolved at run time where optional.
Known limits (spec section 23): SRT broadcast is not available in this build; H.264 uses the Windows Media Foundation
encoder and is not benchmark-qualified; no USB DMX adapter is hardware-qualified; the GUI has had no test on a real Windows desktop.
Supported minimum screen: 800x600 effective client area (smaller areas switch to a scrolling compact layout).
